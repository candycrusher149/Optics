import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { useEffect, useRef, useState, type ReactNode } from "react";

/**
 * VeilSection
 * A section covered by two opaque panels that meet in the middle.
 * When the cursor enters the veil, the panels automatically part —
 * one to the left, one to the right — revealing the hidden content.
 * Pulling the cursor away closes the veil again.
 */
export function VeilSection({
  children,
  hint = "drift the cursor across the veil",
}: { children: ReactNode; hint?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [hovered, setHovered] = useState(false);
  const proximity = useMotionValue(0);
  const smooth = useSpring(proximity, { stiffness: 140, damping: 18, mass: 0.4 });

  // 0 (closed) → 1 (fully open)
  useEffect(() => {
    proximity.set(hovered ? 1 : 0);
  }, [hovered, proximity]);

  const leftX = useTransform(smooth, [0, 1], ["0%", "-100%"]);
  const rightX = useTransform(smooth, [0, 1], ["0%", "100%"]);
  const hintOpacity = useTransform(smooth, [0, 0.4], [1, 0]);

  return (
    <section
      ref={ref}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="relative mx-auto my-32 h-[80vh] max-w-6xl overflow-hidden border border-border/60"
    >
      {/* hidden content underneath */}
      <div className="absolute inset-0 flex items-center justify-center px-6">
        {children}
      </div>

      {/* left curtain */}
      <motion.div
        style={{ x: leftX }}
        className="absolute left-0 top-0 h-full w-1/2 bg-gradient-to-r from-background via-background to-card"
      >
        <div className="absolute right-0 top-0 h-full w-px bg-ember/40" />
      </motion.div>

      {/* right curtain */}
      <motion.div
        style={{ x: rightX }}
        className="absolute right-0 top-0 h-full w-1/2 bg-gradient-to-l from-background via-background to-card"
      >
        <div className="absolute left-0 top-0 h-full w-px bg-ember/40" />
      </motion.div>

      {/* hint */}
      <motion.p
        style={{ opacity: hintOpacity }}
        className="pointer-events-none absolute left-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2 text-center font-script text-2xl text-muted-foreground"
      >
        {hint}
      </motion.p>
    </section>
  );
}
