import { Link, useRouterState } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";

const links = [
  { to: "/", label: "Home", hash: "top" },
  { to: "/", label: "Veil", hash: "veil" },
  { to: "/", label: "How", hash: "how" },
  { to: "/", label: "Footprint", hash: "footprint" },
  { to: "/scan", label: "Scan" },
] as const;

export function SiteNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);

  // briefly reveal on first mount so the user knows it exists
  useEffect(() => {
    setOpen(true);
    const t = setTimeout(() => setOpen(false), 2600);
    return () => clearTimeout(t);
  }, []);

  return (
    <>
      {/* hover trigger zone at the top of the page */}
      <div
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => setOpen(false)}
        className="fixed left-0 right-0 top-0 z-40 h-20"
        aria-hidden
      />

      {/* a subtle thread that hints the nav is there */}
      <motion.div
        aria-hidden
        className="fixed left-1/2 top-0 z-40 h-px -translate-x-1/2 bg-gradient-to-r from-transparent via-ember/60 to-transparent"
        animate={{ width: open ? 0 : 96, opacity: open ? 0 : 0.7 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      />

      <AnimatePresence>
        {open && (
          <motion.header
            key="nav"
            initial={{ y: -30, opacity: 0, filter: "blur(8px)" }}
            animate={{ y: 0, opacity: 1, filter: "blur(0px)" }}
            exit={{ y: -30, opacity: 0, filter: "blur(8px)" }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            onMouseEnter={() => setOpen(true)}
            onMouseLeave={() => setOpen(false)}
            className="fixed left-0 right-0 top-0 z-50 backdrop-blur-xl bg-background/40 border-b border-border/40"
          >
            <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
              <Link to="/" className="font-display text-3xl leading-none">Optic</Link>
              <nav className="hidden gap-10 md:flex">
                {links.map((l) => (
                  <a
                    key={l.label}
                    href={l.to === "/" ? `#${l.hash}` : l.to}
                    onClick={(e) => {
                      if (l.to !== "/") return;
                      e.preventDefault();
                      if (pathname !== "/") {
                        window.location.assign(`/#${l.hash}`);
                        return;
                      }
                      document.getElementById(l.hash)?.scrollIntoView({ behavior: "smooth" });
                    }}
                    className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {l.label}
                  </a>
                ))}
              </nav>
            </div>
          </motion.header>
        )}
      </AnimatePresence>
    </>
  );
}
