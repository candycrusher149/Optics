import { motion, useScroll, useTransform } from "framer-motion";
import { useRef, type ReactNode } from "react";

/**
 * DisintegrateSection
 * A chic scroll-driven dissolve: content blurs, drifts, and fragments
 * into floating motes as the section leaves the viewport.
 */
export function DisintegrateSection({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  const blur = useTransform(scrollYProgress, [0, 0.4, 0.7, 1], [12, 0, 0, 16]);
  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0, 1, 1, 0]);
  const y = useTransform(scrollYProgress, [0, 0.5, 1], [60, 0, -80]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.96, 1, 1.04]);
  const filter = useTransform(blur, (b) => `blur(${b}px)`);

  return (
    <section ref={ref} className="relative mx-auto max-w-5xl px-6 py-40">
      {/* drifting motes */}
      {[...Array(14)].map((_, i) => {
        const mY = useTransform(scrollYProgress, [0, 1], [0, -120 - i * 10]);
        const mOpacity = useTransform(scrollYProgress, [0.4, 0.8], [0, 0.6]);
        return (
          <motion.span
            key={i}
            style={{
              y: mY,
              opacity: mOpacity,
              left: `${(i * 67) % 100}%`,
              top: `${(i * 37) % 100}%`,
            }}
            className="pointer-events-none absolute h-1 w-1 rounded-full bg-ember/70 blur-[1px]"
          />
        );
      })}

      <motion.div style={{ opacity, y, scale, filter }}>
        {children}
      </motion.div>
    </section>
  );
}
