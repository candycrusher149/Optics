import { motion } from "framer-motion";
import type { ReactNode } from "react";
import { SiteNav } from "./site-nav";

export function PageShell({ children }: { children: ReactNode }) {
  return (
    <div className="relative min-h-screen paper-grain grain-overlay overflow-hidden">
      <SiteNav />
      <motion.main
        initial={{ opacity: 0, filter: "blur(12px)" }}
        animate={{ opacity: 1, filter: "blur(0px)" }}
        exit={{ opacity: 0, filter: "blur(12px)" }}
        transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
        className="pt-12"
      >
        {children}
      </motion.main>
      <Footer />
    </div>
  );
}

function Footer() {
  return (
    <footer className="mt-32 border-t border-border px-6 py-10 text-center">
      <p className="font-script text-2xl text-muted-foreground">
        optic
      </p>
      <p className="mt-2 text-[10px] uppercase tracking-[0.4em] text-muted-foreground/60">
        a privacy simulation · not a hacking tool
      </p>
    </footer>
  );
}
