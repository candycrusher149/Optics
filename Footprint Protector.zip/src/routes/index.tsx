import { createFileRoute, Link } from "@tanstack/react-router";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { PageShell } from "@/components/page-shell";
import { VeilSection } from "@/components/veil-section";
import { DisintegrateSection } from "@/components/disintegrate-section";
import { Eye, MapPin, MessageCircle, Sparkles, ImageIcon, Type, Layers } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Optic — See what your posts reveal" },
      { name: "description", content: "AI privacy scanner. Reveal what stalkers, scammers and scrapers can read from your photos and captions — before you post." },
    ],
  }),
  component: Home,
});

const stats = [
  { value: "95%", label: "of teens use social media" },
  { value: "80%", label: "of stalking victims tracked through tech" },
  { value: "61%", label: "of cyberstalkers use everyday tools" },
  { value: "92%", label: "of businesses post for marketing" },
];

const threats = [
  { icon: Eye, title: "What it sees", body: "Logos, landmarks, reflections, the time on the clock behind you." },
  { icon: MapPin, title: "What it infers", body: "Where you live, your school, your gym, the café you visit on Tuesdays." },
  { icon: MessageCircle, title: "What it writes back", body: "A scam message in your friend's voice, with details only you should know." },
];

const readingSteps = [
  { icon: ImageIcon, title: "Pixels", body: "Object detection lifts logos, storefronts, uniforms, and the clock on your wall." },
  { icon: Type, title: "Captions", body: "Language models pull names, moods, and the small confessions you didn't notice." },
  { icon: MessageCircle, title: "Comments", body: "Your social graph becomes legible — who replies, who knows your nickname." },
  { icon: MapPin, title: "Metadata", body: "EXIF data hands over exact coordinates and the camera that took the picture." },
  { icon: Layers, title: "Pattern", body: "One post is noise. Forty posts is a calendar and a list of people who matter." },
];

const timeline = [
  { month: "Jan", insight: "Coffee post from same café → likely lives within 6 blocks." },
  { month: "Mar", insight: "School logo on hoodie → narrows location and age." },
  { month: "May", insight: "Birthday photo timestamp → exact DOB recoverable." },
  { month: "Jul", insight: "Vacation post → home likely empty for 8 days." },
  { month: "Sep", insight: "Gym selfie at 6:42 AM → morning routine confirmed." },
  { month: "Nov", insight: "Tagged friend in story → social graph + secondary location." },
];

function Home() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: containerRef });
  const auroraY = useTransform(scrollYProgress, [0, 1], ["0%", "-30%"]);
  const auroraX = useTransform(scrollYProgress, [0, 1], ["0%", "20%"]);

  return (
    <PageShell>
      <div ref={containerRef} className="relative">
        {/* ambient aurora */}
        <motion.div
          aria-hidden
          style={{ y: auroraY, x: auroraX }}
          className="pointer-events-none fixed inset-0 -z-10"
        >
          <div className="absolute left-[10%] top-[10%] h-[40rem] w-[40rem] rounded-full bg-ocean/20 blur-3xl soft-pulse" />
          <div className="absolute right-[5%] top-[40%] h-[30rem] w-[30rem] rounded-full bg-berry/20 blur-3xl soft-pulse" style={{ animationDelay: "2s" }} />
          <div className="absolute left-[30%] bottom-[5%] h-[36rem] w-[36rem] rounded-full bg-ember/15 blur-3xl soft-pulse" style={{ animationDelay: "4s" }} />
        </motion.div>

        {/* HERO */}
        <section id="top" className="relative mx-auto max-w-6xl px-6 pt-16 pb-40">
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 1.2 }}
            className="text-center text-[10px] uppercase tracking-[0.6em] text-muted-foreground"
          >
            a privacy ritual · for the things you almost posted
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 30, filter: "blur(12px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            transition={{ delay: 0.6, duration: 1.6, ease: [0.22, 1, 0.36, 1] }}
            className="mt-10 text-center text-7xl md:text-[11rem] leading-[0.9] text-balance flicker"
          >
            Optic
            <span className="block font-script text-5xl md:text-7xl text-ember mt-4">before it sees you</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.4, duration: 1.2 }}
            className="mx-auto mt-12 max-w-xl text-center text-lg text-muted-foreground"
          >
            AI doesn't need to hack you. It learns everything from what you post.
            Drift down. Hold a post up to the light.
          </motion.p>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2, duration: 1.4 }}
            className="mt-20 flex flex-col items-center gap-3"
          >
            <span className="text-[10px] uppercase tracking-[0.5em] text-muted-foreground/60">scroll</span>
            <motion.span
              animate={{ y: [0, 8, 0], opacity: [0.4, 1, 0.4] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="h-10 w-px bg-gradient-to-b from-ember to-transparent"
            />
          </motion.div>
        </section>

        {/* THREATS */}
        <section className="mx-auto max-w-6xl px-6 py-32">
          <motion.p
            initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true, margin: "-20%" }}
            transition={{ duration: 1.2 }}
            className="text-center text-[10px] uppercase tracking-[0.5em] text-muted-foreground"
          >
            three quiet things
          </motion.p>
          <div className="mt-16 grid gap-px bg-border/60 md:grid-cols-3">
            {threats.map((t, i) => (
              <motion.div
                key={t.title}
                initial={{ opacity: 0, y: 20, filter: "blur(6px)" }}
                whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                viewport={{ once: true, margin: "-15%" }}
                transition={{ delay: i * 0.15, duration: 1, ease: [0.22, 1, 0.36, 1] }}
                className="group relative bg-background/40 p-10 backdrop-blur-sm transition-colors hover:bg-card/60"
              >
                <t.icon className="h-6 w-6 text-ember" strokeWidth={1.2} />
                <h3 className="mt-6 text-3xl">{t.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{t.body}</p>
                <div className="mt-10 text-[10px] uppercase tracking-[0.4em] text-muted-foreground/50">
                  0{i + 1}
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* VEIL — bidirectional reveal on hover */}
        <section id="veil" className="mx-auto max-w-6xl px-6 pt-24">
          <motion.p
            initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}
            transition={{ duration: 1.2 }}
            className="text-center text-[10px] uppercase tracking-[0.5em] text-muted-foreground"
          >
            behind the veil
          </motion.p>
          <h2 className="mt-6 text-center text-5xl md:text-7xl text-balance">
            move closer
            <span className="block font-script text-ember">it will open for you</span>
          </h2>
        </section>

        <VeilSection hint="hover the veil ✦ it parts on its own">
          <div className="max-w-2xl text-center">
            <Sparkles className="mx-auto h-5 w-5 text-ember" strokeWidth={1} />
            <p className="mt-6 font-script text-4xl md:text-5xl leading-tight text-balance">
              "AI doesn't need to hack you — it learns everything from what you post."
            </p>
            <p className="mt-8 text-sm uppercase tracking-[0.4em] text-muted-foreground">
              you didn't click. it noticed you anyway.
            </p>
          </div>
        </VeilSection>

        {/* HOW AI READS — scroll-revealed */}
        <section id="how" className="mx-auto max-w-4xl px-6 pt-24 pb-12">
          <motion.p
            initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}
            transition={{ duration: 1.2 }}
            className="text-center text-[10px] uppercase tracking-[0.5em] text-muted-foreground"
          >
            a short reading
          </motion.p>
          <h2 className="mt-6 text-center text-6xl md:text-8xl text-balance">
            How AI
            <span className="block font-script text-ember">reads you</span>
          </h2>
        </section>

        <section className="mx-auto max-w-4xl px-6 pb-24">
          <div className="relative">
            <div className="absolute left-10 top-0 bottom-0 w-px bg-border md:left-1/2" />
            {readingSteps.map((s, i) => (
              <motion.div
                key={s.title}
                initial={{ opacity: 0, y: 40, filter: "blur(8px)" }}
                whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                viewport={{ once: true, margin: "-15%" }}
                transition={{ duration: 1, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] }}
                className="relative grid grid-cols-[auto_1fr] gap-8 pb-20 md:grid-cols-2 md:gap-16"
              >
                <div className={`relative ${i % 2 === 0 ? "md:text-right md:pr-12" : "md:order-2 md:pl-12"}`}>
                  <div className="font-display text-[7rem] leading-none text-ember/30">0{i + 1}</div>
                  <h3 className="mt-2 text-4xl">{s.title}</h3>
                </div>
                <div className={`${i % 2 === 0 ? "md:pl-12" : "md:order-1 md:pr-12 md:text-right"} pt-12`}>
                  <s.icon className="h-6 w-6 text-ember" strokeWidth={1.2} />
                  <p className="mt-4 text-lg leading-relaxed text-muted-foreground">{s.body}</p>
                </div>
                <div className="absolute left-10 top-3 h-3 w-3 -translate-x-1/2 rounded-full bg-ember md:left-1/2" />
              </motion.div>
            ))}
          </div>
        </section>

        {/* DISINTEGRATE — chic scroll-dissolve */}
        <DisintegrateSection>
          <p className="text-center text-[10px] uppercase tracking-[0.5em] text-muted-foreground">
            an interlude
          </p>
          <p className="mt-10 text-center font-script text-5xl md:text-7xl leading-tight text-balance">
            one post is a moment.
            <span className="block text-ember">forty posts is a map.</span>
          </p>
          <p className="mt-12 text-center text-sm uppercase tracking-[0.4em] text-muted-foreground/70">
            keep scrolling ✦ it dissolves
          </p>
        </DisintegrateSection>

        {/* FOOTPRINT */}
        <section id="footprint" className="mx-auto max-w-5xl px-6 py-24">
          <motion.p
            initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}
            transition={{ duration: 1.2 }}
            className="text-center text-[10px] uppercase tracking-[0.5em] text-muted-foreground"
          >
            a shadow profile
          </motion.p>
          <h2 className="mt-6 text-center text-5xl md:text-7xl text-balance">
            one year,
            <span className="block font-script text-ember">forty posts</span>
          </h2>
          <div className="mt-16 grid gap-px bg-border/60 md:grid-cols-2">
            {timeline.map((t, i) => (
              <motion.div
                key={t.month}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-10%" }}
                transition={{ delay: i * 0.07, duration: 0.9 }}
                className="group relative bg-background/40 p-10 backdrop-blur-sm transition-colors hover:bg-card/60"
              >
                <div className="flex items-baseline gap-4">
                  <span className="font-display text-5xl text-ember">{t.month}</span>
                  <span className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">post {i * 7 + 3}</span>
                </div>
                <p className="mt-4 text-lg leading-relaxed">{t.insight}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* STATS */}
        <section className="mx-auto max-w-6xl px-6 py-24">
          <p className="text-center text-[10px] uppercase tracking-[0.5em] text-muted-foreground">
            the quiet arithmetic
          </p>
          <div className="mt-12 grid gap-px bg-border/60 sm:grid-cols-2 lg:grid-cols-4">
            {stats.map((s, i) => (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, filter: "blur(8px)" }}
                whileInView={{ opacity: 1, filter: "blur(0px)" }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.12, duration: 1 }}
                className="bg-background/40 p-10 backdrop-blur-sm"
              >
                <div className="font-display text-7xl text-foreground">{s.value}</div>
                <div className="mt-3 text-xs leading-relaxed text-muted-foreground">{s.label}</div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* CTA — closing */}
        <section className="mx-auto max-w-4xl px-6 pb-40 pt-24 text-center">
          <motion.h2
            initial={{ opacity: 0, y: 20, filter: "blur(10px)" }}
            whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            viewport={{ once: true }}
            transition={{ duration: 1.4 }}
            className="text-5xl md:text-7xl text-balance"
          >
            Hold it up to the light.
          </motion.h2>
          <p className="mt-6 font-script text-2xl text-muted-foreground">before you press post</p>

          <Link
            to="/scan"
            search={{ demo: "maya" }}
            className="group relative mt-16 inline-block overflow-hidden bg-foreground px-12 py-4 text-xs uppercase tracking-[0.4em] text-background transition-all hover:tracking-[0.5em] ember-glow"
          >
            <span className="relative z-10">Scan a post</span>
          </Link>
        </section>
      </div>
    </PageShell>
  );
}
