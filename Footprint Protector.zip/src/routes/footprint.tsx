import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { PageShell } from "@/components/page-shell";

export const Route = createFileRoute("/footprint")({
  head: () => ({
    meta: [
      { title: "Shadow footprint — Optic" },
      { name: "description", content: "A sample shadow profile assembled from a year of harmless posts." },
    ],
  }),
  component: FootprintPage,
});

const timeline = [
  { month: "Jan", insight: "Coffee post from same café, 3 mornings/week → likely lives within 6 blocks." },
  { month: "Mar", insight: "School logo visible on hoodie → narrows location and age." },
  { month: "May", insight: "Birthday photo timestamp → exact DOB recoverable." },
  { month: "Jul", insight: "Vacation post → home likely empty for 8 days." },
  { month: "Sep", insight: "Gym selfie at 6:42 AM, repeated → morning routine confirmed." },
  { month: "Nov", insight: "Tagged friend's address in story → social graph + secondary location." },
];

function FootprintPage() {
  return (
    <PageShell>
      <section className="mx-auto max-w-4xl px-6 pb-20">
        <p className="text-center text-[11px] uppercase tracking-[0.5em] text-muted-foreground">a shadow profile</p>
        <h1 className="mt-6 text-center text-6xl md:text-8xl text-balance">
          One year,
          <span className="block font-script text-ember">forty posts</span>
        </h1>
        <p className="mx-auto mt-8 max-w-xl text-center text-muted-foreground">
          A composite portrait, drawn entirely from things that felt like nothing at the time.
        </p>
      </section>

      <section className="mx-auto max-w-5xl px-6 pb-24">
        <div className="grid gap-px bg-border md:grid-cols-2">
          {timeline.map((t, i) => (
            <motion.div
              key={t.month}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.07 }}
              className="group relative bg-background p-10 transition-colors hover:bg-card"
            >
              <div className="flex items-baseline gap-4">
                <span className="font-display text-5xl text-ember">{t.month}</span>
                <span className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">post {i * 7 + 3}</span>
              </div>
              <p className="mt-4 text-lg leading-relaxed">{t.insight}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-6 pb-32 text-center">
        <h2 className="text-5xl md:text-6xl text-balance">The profile you didn't write.</h2>
        <p className="mt-6 font-script text-2xl text-muted-foreground">
          home · school · routine · friends · the days you'll be away
        </p>
        <Link
          to="/scan"
          className="mt-12 inline-block border border-foreground px-10 py-4 text-xs uppercase tracking-[0.32em] transition-all hover:bg-foreground hover:text-background hover:tracking-[0.4em]"
        >
          Scan your next post
        </Link>
      </section>
    </PageShell>
  );
}
