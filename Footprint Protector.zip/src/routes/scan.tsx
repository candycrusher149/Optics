import { createFileRoute } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { z } from "zod";
import { PageShell } from "@/components/page-shell";
import {
  Upload, AlertTriangle, MapPin, Clock, Tag, Eye, MessageSquare,
  Shield, Sparkles, Scissors, EyeOff, Pencil, Timer, Check, X,
} from "lucide-react";
import mayaCafe from "@/assets/maya-cafe.jpg";

const scanSearchSchema = z.object({
  demo: z.union([z.literal("maya"), z.literal("1"), z.literal("true")]).optional(),
});

export const Route = createFileRoute("/scan")({
  validateSearch: scanSearchSchema,
  head: () => ({
    meta: [
      { title: "Scan a post — Optic" },
      { name: "description", content: "Upload an image and caption — or run the Maya scenario — and see exactly what an AI scraper, scammer, or stalker can read from it." },
    ],
  }),
  component: ScanPage,
});

type Stage = "idle" | "scenario-intro" | "scanning" | "results" | "fixes" | "final";

const scanSteps = [
  "Analyzing visual data",
  "Detecting identity signals",
  "Cross-referencing comments",
  "Simulating external threat view",
  "Drafting a personalized scam",
];

function ScanPage() {
  const { demo } = Route.useSearch();
  const [stage, setStage] = useState<Stage>("idle");
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [caption, setCaption] = useState("");
  const [stepIdx, setStepIdx] = useState(0);
  const [scenario, setScenario] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => setImageUrl(URL.createObjectURL(file));

  const runScenario = () => {
    setScenario(true);
    setImageUrl(mayaCafe);
    setCaption("same routine, different day ☕️");
    setStage("scenario-intro");
  };

  useEffect(() => {
    if (demo && stage === "idle") runScenario();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [demo]);

  const beginScan = () => {
    setStage("scanning");
    setStepIdx(0);
    scanSteps.forEach((_, i) => setTimeout(() => setStepIdx(i), i * 800));
    setTimeout(() => setStage("results"), scanSteps.length * 800 + 500);
  };

  const startScanFromIdle = () => {
    if (!imageUrl) return;
    beginScan();
  };

  const reset = () => {
    setStage("idle");
    setImageUrl(null);
    setCaption("");
    setScenario(false);
  };

  return (
    <PageShell>
      <section className="mx-auto max-w-5xl px-6 pb-32">
        <AnimatePresence mode="wait">
          {stage === "idle" && (
            <motion.div key="idle" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.5 }}>
              <h1 className="text-center text-6xl md:text-8xl text-balance">
                Show us
                <span className="block font-script text-ember">what you almost posted</span>
              </h1>
              <p className="mx-auto mt-6 max-w-xl text-center text-muted-foreground">
                Drag a photo in, or watch the scan run on a scripted scenario.
              </p>

              <div className="mt-10 flex justify-center">
                <button
                  onClick={runScenario}
                  className="group inline-flex items-center gap-3 border border-ember/60 bg-ember/10 px-6 py-3 text-xs uppercase tracking-[0.32em] text-ember transition-all hover:bg-ember hover:text-background hover:tracking-[0.4em]"
                >
                  <Sparkles className="h-4 w-4" strokeWidth={1.2} />
                  Run the Maya scenario
                </button>
              </div>

              <div className="my-10 flex items-center gap-4 text-[10px] uppercase tracking-[0.4em] text-muted-foreground/60">
                <div className="h-px flex-1 bg-border" /> or upload your own <div className="h-px flex-1 bg-border" />
              </div>

              <div className="grid gap-8 md:grid-cols-[1.2fr_1fr]">
                <button
                  onClick={() => inputRef.current?.click()}
                  className="group relative aspect-[4/5] overflow-hidden border border-dashed border-border bg-card/40 transition-all hover:border-foreground"
                >
                  {imageUrl ? (
                    <img src={imageUrl} alt="upload preview" className="h-full w-full object-cover" />
                  ) : (
                    <div className="flex h-full flex-col items-center justify-center gap-4 text-muted-foreground transition-colors group-hover:text-foreground">
                      <Upload strokeWidth={1} className="h-10 w-10" />
                      <p className="font-script text-2xl">drop a photo</p>
                      <p className="text-[10px] uppercase tracking-[0.4em]">or click to choose</p>
                    </div>
                  )}
                  <input ref={inputRef} type="file" accept="image/*" className="hidden"
                    onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
                </button>

                <div className="flex flex-col">
                  <label className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">caption</label>
                  <textarea
                    value={caption}
                    onChange={(e) => setCaption(e.target.value)}
                    placeholder="my usual tuesday coffee at joe's ☕"
                    className="mt-3 flex-1 resize-none border border-border bg-card/40 p-6 font-sans text-lg leading-relaxed text-foreground placeholder:text-muted-foreground/60 focus:border-foreground focus:outline-none"
                  />
                  <button
                    onClick={startScanFromIdle}
                    disabled={!imageUrl}
                    className="group relative mt-6 overflow-hidden border border-foreground bg-foreground px-8 py-4 text-xs uppercase tracking-[0.32em] text-background transition-all hover:tracking-[0.4em] disabled:cursor-not-allowed disabled:border-border disabled:bg-transparent disabled:text-muted-foreground"
                  >
                    Begin the scan
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {stage === "scenario-intro" && (
            <ScenarioIntro key="intro" onContinue={beginScan} onReset={reset} />
          )}

          {stage === "scanning" && imageUrl && (
            <motion.div key="scanning" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.6 }} className="flex flex-col items-center">
              <p className="text-[10px] uppercase tracking-[0.5em] text-ember">VaultLens · scanning</p>
              <div className="relative mt-8 aspect-[4/5] w-full max-w-md overflow-hidden border border-border">
                <img src={imageUrl} alt="" className="h-full w-full object-cover opacity-70" />
                <div className="absolute inset-0 bg-gradient-to-b from-ember/0 via-ember/30 to-ember/0 scan-line" />
                <div className="absolute inset-0 ring-1 ring-inset ring-ember/30" />
                {/* corner ticks */}
                {["top-2 left-2","top-2 right-2","bottom-2 left-2","bottom-2 right-2"].map(c => (
                  <span key={c} className={`absolute h-4 w-4 border-ember ${c} ${c.includes('top') ? 'border-t' : 'border-b'} ${c.includes('left') ? 'border-l' : 'border-r'}`} />
                ))}
              </div>
              <div className="mt-10 h-6 overflow-hidden">
                <AnimatePresence mode="wait">
                  <motion.p key={stepIdx}
                    initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -20, opacity: 0 }}
                    transition={{ duration: 0.4 }}
                    className="font-script text-2xl text-foreground">
                    {scanSteps[stepIdx]}…
                  </motion.p>
                </AnimatePresence>
              </div>
            </motion.div>
          )}

          {stage === "results" && imageUrl && (
            <Results key="results" imageUrl={imageUrl} caption={caption} scenario={scenario}
              onReset={reset} onFix={() => setStage("fixes")} />
          )}

          {stage === "fixes" && imageUrl && (
            <Fixes key="fixes" imageUrl={imageUrl} onContinue={() => setStage("final")} />
          )}

          {stage === "final" && imageUrl && (
            <FinalCompare key="final" imageUrl={imageUrl} onReset={reset} />
          )}
        </AnimatePresence>
      </section>
    </PageShell>
  );
}

/* ---------- SCENARIO INTRO ---------- */
function ScenarioIntro({ onContinue, onReset }: { onContinue: () => void; onReset: () => void }) {
  const comments = [
    { name: "lily.j", text: "you always go there after school lol" },
    { name: "coach_m", text: "see you tomorrow at practice!" },
    { name: "noor.x", text: "matcha gang 💚" },
  ];
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.6 }}>
      <p className="text-center text-[11px] uppercase tracking-[0.5em] text-muted-foreground">a scenario · meet maya, 16</p>
      <h2 className="mt-4 text-center text-5xl md:text-7xl text-balance">
        a normal aesthetic post
        <span className="block font-script text-ember">about to be shared</span>
      </h2>

      <div className="mt-16 grid gap-10 md:grid-cols-[1fr_1fr]">
        {/* mock instagram card */}
        <div className="mx-auto w-full max-w-md border border-border bg-card">
          <div className="flex items-center gap-3 border-b border-border p-4">
            <div className="h-9 w-9 rounded-full bg-gradient-to-br from-ember to-foreground/40" />
            <div>
              <div className="text-sm font-medium">maya.k</div>
              <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">just now · café</div>
            </div>
          </div>
          <img src={mayaCafe} alt="Maya's draft post" className="aspect-square w-full object-cover" />
          <div className="p-4">
            <p className="text-sm"><span className="font-medium">maya.k</span> same routine, different day ☕️</p>
            <div className="mt-4 space-y-2 border-t border-border pt-3">
              {comments.map((c, i) => (
                <motion.div key={c.name}
                  initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + i * 0.2 }}
                  className="text-xs text-muted-foreground">
                  <span className="text-foreground">{c.name}</span> {c.text}
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex flex-col justify-center">
          <p className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">what's in the frame</p>
          <ul className="mt-6 space-y-4 text-lg">
            {[
              "an iced matcha she just ordered",
              "the café logo, faintly, on the window",
              "a street sign visible through the glass",
              "her school hoodie on the chair",
              "a caption that says 'same routine'",
            ].map((line, i) => (
              <motion.li key={line} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 + i * 0.1 }}
                className="flex items-start gap-3">
                <span className="mt-2 h-1 w-6 bg-ember" />
                <span>{line}</span>
              </motion.li>
            ))}
          </ul>
          <p className="mt-10 font-script text-2xl text-muted-foreground">
            she doesn't think much of it. she's about to hit post.
          </p>
          <div className="mt-10 flex flex-wrap gap-4">
            <button onClick={onContinue}
              className="group inline-flex items-center gap-3 bg-foreground px-8 py-4 text-xs uppercase tracking-[0.32em] text-background transition-all hover:tracking-[0.4em] ember-glow">
              <Sparkles className="h-4 w-4" /> Activate VaultLens
            </button>
            <button onClick={onReset}
              className="text-xs uppercase tracking-[0.32em] text-muted-foreground hover:text-foreground">
              cancel
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

/* ---------- RESULTS ---------- */
function Results({ imageUrl, caption, scenario, onReset, onFix }: {
  imageUrl: string; caption: string; scenario: boolean; onReset: () => void; onFix: () => void;
}) {
  const findings = scenario ? [
    { icon: MapPin, tag: "Location", text: "Café identifiable from logo + interior design. Street sign through the window narrows the block." },
    { icon: Tag, tag: "Identity", text: "School hoodie reveals which school — and therefore the age band, neighborhood, and weekly schedule." },
    { icon: Clock, tag: "Routine", text: "'Same routine' caption + after-school timing = predictable arrival window, 5 days a week." },
    { icon: Eye, tag: "Pattern", text: "3rd café post this month from the same spot. The pattern is now confirmable." },
  ] : [
    { icon: MapPin, tag: "Location", text: "Visible context in the frame narrows your area to within a few blocks." },
    { icon: Clock, tag: "Routine", text: "Time-of-day and language hints suggest a repeatable weekly pattern." },
    { icon: Tag, tag: "Identity", text: "Logos and clothing in the frame are readable to object detection." },
    { icon: Eye, tag: "Metadata", text: "EXIF data on the original file likely contains GPS coordinates." },
  ];

  const comments = scenario ? [
    { from: "lily.j", text: "you always go there after school lol", reason: "confirms the routine pattern" },
    { from: "coach_m", text: "see you tomorrow at practice!", reason: "confirms day-of-week schedule + activity" },
  ] : [];

  const risk = scenario ? 88 : 72;
  const level = risk > 75 ? "High" : risk > 55 ? "Medium" : "Low";

  return (
    <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.7 }}>
      <div className="grid gap-10 md:grid-cols-[1fr_1.4fr]">
        <div>
          <div className="relative aspect-[4/5] overflow-hidden border border-border">
            <img src={imageUrl} alt="" className="h-full w-full object-cover" />
            {scenario && (
              <>
                <Tag2 pos="top-[18%] left-[20%]" label="café logo" />
                <Tag2 pos="top-[6%] right-[16%]" label="street sign" />
                <Tag2 pos="top-[42%] left-[12%]" label="school hoodie" />
                <Tag2 pos="bottom-[28%] left-[40%]" label="iced matcha" />
              </>
            )}
          </div>
          {caption && (
            <p className="mt-4 font-script text-xl text-muted-foreground">"{caption}"</p>
          )}
        </div>

        <div>
          <p className="text-[10px] uppercase tracking-[0.5em] text-muted-foreground">VaultLens · privacy risk report</p>
          <div className="mt-4 flex items-end gap-6">
            <div className="font-display text-[7rem] leading-none text-ember">{risk}</div>
            <div className="pb-4">
              <div className="text-xs uppercase tracking-[0.3em] text-muted-foreground">level</div>
              <div className="font-script text-3xl text-foreground">{level}</div>
            </div>
          </div>

          <div className="mt-10 space-y-px bg-border">
            {findings.map((f, i) => (
              <motion.div key={i} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 + i * 0.1 }}
                className="flex items-start gap-4 bg-card p-5">
                <f.icon className="mt-1 h-4 w-4 shrink-0 text-ember" strokeWidth={1.2} />
                <div className="min-w-0">
                  <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">{f.tag}</div>
                  <p className="mt-1 text-sm text-foreground">{f.text}</p>
                </div>
              </motion.div>
            ))}
          </div>

          {comments.length > 0 && (
            <div className="mt-10">
              <p className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">comment leak warning</p>
              <div className="mt-4 space-y-3">
                {comments.map((c, i) => (
                  <motion.div key={i} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 + i * 0.15 }}
                    className="border-l-2 border-ember/70 bg-card/60 p-4">
                    <p className="text-sm"><span className="text-foreground">{c.from}</span> <span className="text-muted-foreground">{c.text}</span></p>
                    <p className="mt-2 text-[10px] uppercase tracking-[0.3em] text-ember">→ {c.reason}</p>
                  </motion.div>
                ))}
              </div>
              <p className="mt-4 font-script text-xl text-muted-foreground">
                comments are reinforcing a predictable behavior loop.
              </p>
            </div>
          )}

          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.9 }}
            className="mt-10 parchment-card p-8">
            <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.4em] opacity-60">
              <MessageSquare className="h-3 w-3" /> a scam written from this post
            </div>
            <p className="mt-4 font-script text-2xl leading-snug">
              {scenario
                ? "\"hey maya! we noticed you're a regular at the café near your school — here's a student discount, just verify your details: [link]\""
                : "\"hey! saw you were at joe's again ☕ wanna grab a coffee thursday? sent you a link to pick a time\""}
            </p>
            <p className="mt-4 text-xs opacity-60">
              Built from: location, school, routine. Convincing in under 4 seconds.
            </p>
          </motion.div>

          <div className="mt-10 flex flex-wrap gap-4">
            <button onClick={onFix}
              className="group inline-flex items-center gap-3 bg-foreground px-8 py-4 text-xs uppercase tracking-[0.32em] text-background transition-all hover:tracking-[0.4em] ember-glow">
              <Shield className="h-4 w-4" /> Fix & protect
            </button>
            <button onClick={onReset}
              className="border border-foreground/40 px-8 py-4 text-xs uppercase tracking-[0.32em] text-foreground transition-colors hover:bg-foreground hover:text-background">
              Scan another
            </button>
          </div>
        </div>
      </div>

      <div className="mt-20 flex items-center justify-center gap-3 text-muted-foreground">
        <AlertTriangle className="h-4 w-4" strokeWidth={1.2} />
        <p className="text-[10px] uppercase tracking-[0.4em]">simulation for awareness — no scraping occurred</p>
      </div>
    </motion.div>
  );
}

function Tag2({ pos, label }: { pos: string; label: string }) {
  return (
    <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.4 + Math.random() * 0.4 }}
      className={`absolute ${pos} flex items-center gap-2`}>
      <span className="h-2 w-2 rounded-full bg-ember ring-4 ring-ember/20" />
      <span className="whitespace-nowrap bg-background/80 px-2 py-1 text-[9px] uppercase tracking-[0.25em] text-ember backdrop-blur">{label}</span>
    </motion.div>
  );
}

/* ---------- FIXES ---------- */
function Fixes({ imageUrl, onContinue }: { imageUrl: string; onContinue: () => void }) {
  const [applied, setApplied] = useState<Record<string, boolean>>({});
  const fixes = [
    { id: "crop", icon: Scissors, title: "Crop background", body: "Remove the café signage and the street sign through the window." },
    { id: "blur", icon: EyeOff, title: "Blur the hoodie logo", body: "School logo is the single strongest identity signal in the frame." },
    { id: "caption", icon: Pencil, title: "Soften the caption", body: "Replace 'same routine, different day' → 'slow afternoons ☕️'" },
    { id: "delay", icon: Timer, title: "Post 2–3 hours later", body: "Breaks the real-time tracking window without losing the post." },
  ];
  const all = fixes.every(f => applied[f.id]);
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.6 }}>
      <p className="text-center text-[11px] uppercase tracking-[0.5em] text-muted-foreground">VaultLens · suggested fixes</p>
      <h2 className="mt-4 text-center text-5xl md:text-7xl text-balance">
        four small changes
        <span className="block font-script text-ember">a different post entirely</span>
      </h2>

      <div className="mt-14 grid gap-8 md:grid-cols-[1fr_1.2fr]">
        <div className="relative aspect-[4/5] overflow-hidden border border-border">
          <img src={imageUrl} alt="" className="h-full w-full object-cover transition-all duration-700"
            style={{
              filter: `${applied.crop ? "brightness(0.9)" : ""} ${applied.blur ? "blur(0px)" : ""}`,
              clipPath: applied.crop ? "inset(18% 8% 8% 8%)" : undefined,
            }} />
          {applied.blur && (
            <div className="absolute top-[38%] left-[8%] h-[18%] w-[28%] backdrop-blur-md bg-background/30 border border-ember/40" />
          )}
          {applied.crop && (
            <div className="absolute inset-0 ring-1 ring-inset ring-ember/40 pointer-events-none" />
          )}
        </div>

        <div className="space-y-px bg-border">
          {fixes.map((f) => {
            const on = !!applied[f.id];
            return (
              <button key={f.id}
                onClick={() => setApplied((s) => ({ ...s, [f.id]: !s[f.id] }))}
                className={`group flex w-full items-start gap-4 p-5 text-left transition-colors ${on ? "bg-ember/15" : "bg-card hover:bg-card/70"}`}>
                <f.icon className={`mt-1 h-5 w-5 shrink-0 transition-colors ${on ? "text-ember" : "text-muted-foreground"}`} strokeWidth={1.2} />
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-foreground">{f.title}</div>
                  <p className="mt-1 text-xs text-muted-foreground">{f.body}</p>
                </div>
                <div className={`mt-1 flex h-5 w-5 shrink-0 items-center justify-center border ${on ? "border-ember bg-ember text-background" : "border-border"}`}>
                  {on && <Check className="h-3 w-3" strokeWidth={2} />}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="mt-12 flex justify-center">
        <button onClick={onContinue} disabled={!all}
          className="group bg-foreground px-10 py-4 text-xs uppercase tracking-[0.32em] text-background transition-all hover:tracking-[0.4em] ember-glow disabled:opacity-40 disabled:cursor-not-allowed">
          {all ? "See the comparison" : `apply all ${Object.values(applied).filter(Boolean).length}/4`}
        </button>
      </div>
    </motion.div>
  );
}

/* ---------- FINAL ---------- */
function FinalCompare({ imageUrl, onReset }: { imageUrl: string; onReset: () => void }) {
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.6 }}>
      <p className="text-center text-[11px] uppercase tracking-[0.5em] text-muted-foreground">final decision</p>
      <h2 className="mt-4 text-center text-5xl md:text-7xl text-balance">
        before
        <span className="font-script text-ember"> & </span>
        after
      </h2>

      <div className="mt-14 grid gap-px bg-border md:grid-cols-2">
        <div className="bg-background p-6">
          <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.4em] text-destructive">
            <X className="h-3 w-3" /> original — high risk
          </div>
          <div className="mt-4 aspect-[4/5] overflow-hidden border border-destructive/40">
            <img src={imageUrl} alt="" className="h-full w-full object-cover" />
          </div>
          <p className="mt-4 font-script text-xl text-muted-foreground">"same routine, different day ☕️"</p>
          <ul className="mt-4 space-y-1 text-xs text-muted-foreground">
            <li>· café identifiable</li>
            <li>· school revealed</li>
            <li>· routine confirmed</li>
            <li>· posted in real time</li>
          </ul>
        </div>

        <div className="bg-background p-6">
          <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.4em] text-ember">
            <Check className="h-3 w-3" /> edited — low risk
          </div>
          <div className="mt-4 aspect-[4/5] overflow-hidden border border-ember/40">
            <div className="relative h-full w-full">
              <img src={imageUrl} alt="" className="h-full w-full object-cover"
                style={{ clipPath: "inset(18% 8% 8% 8%)", filter: "brightness(0.95)" }} />
              <div className="absolute top-[38%] left-[8%] h-[18%] w-[28%] backdrop-blur-md bg-background/30" />
            </div>
          </div>
          <p className="mt-4 font-script text-xl text-muted-foreground">"slow afternoons ☕️"</p>
          <ul className="mt-4 space-y-1 text-xs text-muted-foreground">
            <li>· no café signage</li>
            <li>· hoodie logo blurred</li>
            <li>· no routine signal</li>
            <li>· delayed by 2 hours</li>
          </ul>
        </div>
      </div>

      <div className="mt-12 flex flex-col items-center gap-6 text-center">
        <p className="font-script text-3xl text-balance max-w-xl">
          same moment. same matcha. without the map to find her.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <button className="group inline-flex items-center gap-3 bg-ember px-10 py-4 text-xs uppercase tracking-[0.32em] text-background transition-all hover:tracking-[0.4em] ember-glow">
            <Check className="h-4 w-4" /> Post safely
          </button>
          <button onClick={onReset}
            className="border border-foreground/40 px-10 py-4 text-xs uppercase tracking-[0.32em] text-foreground transition-colors hover:bg-foreground hover:text-background">
            Run another scan
          </button>
        </div>
      </div>
    </motion.div>
  );
}
