import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { PageShell } from "@/components/page-shell";
import { ImageIcon, Type, MessageCircle, MapPin, Layers } from "lucide-react";

export const Route = createFileRoute("/learn")({
  head: () => ({
    meta: [
      { title: "How AI reads you — Optic" },
      { name: "description", content: "A walk through the five ways AI extracts identity, location, and routine from your social posts." },
    ],
  }),
  component: LearnPage,
});

const steps = [
  { icon: ImageIcon, title: "Pixels", body: "Object detection lifts logos, storefronts, uniforms, license plates, and the clock on your wall." },
  { icon: Type, title: "Captions", body: "Language models pull names, moods, places, and the small confessions you didn't realize were confessions." },
  { icon: MessageCircle, title: "Comments", body: "Your social graph becomes legible — who replies, who knows your nickname, who saw you yesterday." },
  { icon: MapPin, title: "Metadata", body: "EXIF data hands over exact coordinates and the model of camera that took the picture." },
  { icon: Layers, title: "Cross-post pattern", body: "One post is noise. Forty posts is a calendar, a commute, and a list of people who matter to you." },
];

function LearnPage() {
  return (
    <PageShell>
      <section className="mx-auto max-w-3xl px-6 pb-24">
        <p className="text-center text-[11px] uppercase tracking-[0.5em] text-muted-foreground">a short reading</p>
        <h1 className="mt-6 text-center text-6xl md:text-8xl text-balance">
          How AI
          <span className="block font-script text-ember">reads you</span>
        </h1>
        <p className="mx-auto mt-8 max-w-xl text-center text-muted-foreground">
          Five layers. Each one feels harmless on its own. Stacked, they're a profile.
        </p>
      </section>

      <section className="mx-auto max-w-4xl px-6 pb-32">
        <div className="relative">
          <div className="absolute left-10 top-0 bottom-0 w-px bg-border md:left-1/2" />
          {steps.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: i * 0.05 }}
              className="relative grid grid-cols-[auto_1fr] gap-8 pb-20 md:grid-cols-2 md:gap-16"
            >
              <div className={`relative ${i % 2 === 0 ? "md:text-right md:pr-12" : "md:order-2 md:pl-12"}`}>
                <div className="font-display text-[8rem] leading-none text-ember/40">0{i + 1}</div>
                <h3 className="mt-2 text-4xl">{s.title}</h3>
              </div>
              <div className={`${i % 2 === 0 ? "md:pl-12" : "md:order-1 md:pr-12 md:text-right"} pt-12`}>
                <s.icon className="h-6 w-6 text-ember" strokeWidth={1.2} />
                <p className="mt-4 text-lg leading-relaxed text-muted-foreground">{s.body}</p>
              </div>
              <div className="absolute left-10 top-3 h-3 w-3 -translate-x-1/2 rounded-full bg-ember md:left-1/2" />
            </motion.div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-6 pb-32 text-center">
        <p className="font-script text-4xl md:text-5xl leading-tight text-balance">
          One post is a moment. Forty posts is a map.
        </p>
      </section>
    </PageShell>
  );
}
